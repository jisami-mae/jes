# School Management System PHP \& MYSQL

version: 1.0.0

## TECHNOLOGIES

1. PHP
2. MYSQL
3. BOOTSTRAP 5
4. HTML
5. CSS
6. JS

## Full Tutorial

Installation



Place the project files in your web server's document root directory (e.g., htdocs for XAMPP).



Set up the MySQL database:



Create a new database for the project.

Import the provided SQL dump file (database.sql) into the newly created database.

Configure the database connection:

Open the config.php file located in the includes directory.

Update the database configuration variables with your MySQL database details.

Start your web server.



Access the application in your web browser at http://localhost/school-management-system-php



Authors

Jessamae Liba

